import { Test, TestingModule } from '@nestjs/testing';
import { PostsService } from './posts.service';

describe('PostsService', () => {
  let service: PostsService;
  
  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PostsService],
    }).compile();
    service = module.get<PostsService>(PostsService);
  });
  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
